// import {hombre, mujer, niños, deportivos, etiqueta, personalizados } from "./datashoes.js";
const URL_API = "http://localhost:3000/";

let hombre = [];

const containerCards = document.getElementById("containerCards");

const getHombre = async(url) =>{
    try {
        const endpoint = "hombre";
        const resp = await fetch(`${URL_API}${endpoint}`);
        const response = await resp.json();

        return response;
    } catch (error) {
        console.log(error);
        return[];
    }
}

const printCards = (hombre, container) => {
    container.innerHTML = "";
    hombre.forEach((element) => {
        container.innerHTML += `
        <article class="card">
        <figure class="card__figure">
        <img src=${element.imagen} alt=${element.nombre}>
        <div class="card__infoImage">
        <div class="info">
        <span class="material-symbols-outlined" class="info">
        info
        </span>
        </div>
        <div  class="favorite">
        <span class="material-symbols-outlined">
                    favorite
                    </span>
                    </div>
                    <div  class="cart">
                    <span class="material-symbols-outlined">
                    shopping_cart
                    </span>
                    </div>
        </div>
    </figure>
    <section class="card__body">
    <h3 class="card__name">${element.nombre}</h3>
    <h4 class="card__marca">${element.marca}</h4>
    <span class="card__price">$${Number(element.precio)}</span>
    <br>
    <span class="card__stock">${Number(element.stock)}</span>  
    </section>
    <section class="card__button">
                <button class="card__btn">Add</button>
    </section>
    </article>`;    
    });
};

    hombre = await getHombre(URL_API);
    printCards(hombre,containerCards);




// const icons = document.querySelectorAll('.info');
// const iconsArray = Array.from(icons);

// iconsArray.forEach((icon) => {
//   icon.addEventListener('click', function() {
//     console.log('hice click');
//   });
// });
const icons = document.querySelectorAll('.info');

icons.forEach((icon) => {
  icon.addEventListener('click', function() {
    const index =this.getAttribute('data-index');
    window.location.href = `./pages/info.html?index=${index}`;
  });
});

